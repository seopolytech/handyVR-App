<?php
	##########################################
	# Manage Web Site Global Server-Side Script
	# MYSQL Configuration
	##########################################
	$MYSQL['_adminDB']						= "tbl_admin";
	$MYSQL['_typeDB']						= "tbl_type";
	$MYSQL['_dataDB']						= "tbl_data";
	$MYSQL['_videoDB']                      = "tbl_video";
?>